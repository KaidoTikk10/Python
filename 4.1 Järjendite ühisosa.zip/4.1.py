def yhisosa(tulp1, tulp2):
    tulemus = {}
    hulk1 = set(tulp1)
    hulk2 = set(tulp2)
    tulemus = hulk1 & hulk2
    return list(tulemus)
tulp1 = [1, 2]
tulp2 = [2, 3]
print(yhisosa(tulp1,tulp2))
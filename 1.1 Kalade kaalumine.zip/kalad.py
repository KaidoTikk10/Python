def kala_kaal(tulemused,fulton):
    return round(int(tulemused ** 3) * (float(fulton) / 100))
fail = input("Sisestage failinimi: ")
moot = int(input("Sisestage püügi alamõõt: "))
fulton = float(input("Sisestage Fultoni tüsedusindeks: "))
kalad = []
kaal = []
f = open(fail)
for rida in f:
    rida = int(rida)
    kalad.append(rida)
for tulemused in kalad:    
    if tulemused < moot:
        print("Kala lasti vette tagasi")
    elif tulemused >= moot:
        arv = kala_kaal(tulemused, fulton)
        print("Püütud kala kaaluga:", str(arv),"grammi")
        kaal += [arv]
suurim = max(kaal)
print ("Kõige raskem püütud kala:",float(suurim / 1000),"kg")
    
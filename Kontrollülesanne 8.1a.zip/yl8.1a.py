fail = input("Sisestage failinimi: ")
kasv = float(input("Sisestage aastane juurdekasv hektari kohta tihumeetrites: "))
piir = float(input("Sisestage piir, mitmest aakrist suuremad metsatükid arvesse võtta: "))
def juurdekasv(arvtagasi, kasv):
    return round((arvtagasi * 0.4047 * kasv), 2)
tulemus = []
arvtagasi = []
f = open(fail)
for rida in f:
    tulemus.append(float(rida))
for tulemused in tulemus:    
    if tulemused <= piir:
        print("Metsatükki ei võeta arvesse")
    elif tulemused > piir:
        arvtagasi.append(float(tulemused))
        arv = juurdekasv(tulemused, kasv)
        print("Metsatüki aastane juurdekasv on", float(arv))
print("Arvutati",len(arvtagasi),"metsatüki juurdekasv.")
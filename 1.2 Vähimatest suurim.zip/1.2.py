def vahimatest_suurim(maatriks):
    vahim = []
    for rida in maatriks:
        vahim.append(min(rida))
    return (max(vahim))
maatriks = [[3, 0], [0, -1], [2, 1]]
print(vahimatest_suurim(maatriks))
bingo_tabel = [['X', 'X', 'X', 'X', 'X'],
 ['X', 'X', 'X', 49, 65],
 [10, 'X', 42, 60, 74],
 [3, 24, 41, 51, 62],
 ['X', 'X', 45, 49, 61]]
def voitis_nurkademangu(bingo_tabel):  
    return bingo_tabel[0][0] == 'X' and bingo_tabel[0][4] == 'X' and bingo_tabel[4][0] == 'X' and bingo_tabel[4][4] == 'X'

    
def x_peadiagonaalil(bingo_tabel):
    kokku = 0
    for i in range(5):
        if bingo_tabel[i][i] == 'X':
            kokku += 1
    return kokku 

def x_korvaldiagonaalil(bingo_tabel):
    x_arv =  0
    counter = 5
    for i in range(5):
        counter -= 1
        if bingo_tabel[i][counter] == 'X':
            x_arv += 1
    return x_arv 

def voitis_diagonaalidemangu(bingo_tabel):
    return x_peadiagonaalil(bingo_tabel) == 5 and x_korvaldiagonaalil(bingo_tabel) == 5

def voitis_taismangu(bingo_tabel):
    kokku = 0
    for rida in bingo_tabel:
        for arv in rida:
            if arv == 'X':
                kokku += 1
    return kokku == 25

print(voitis_nurkademangu(bingo_tabel))
print(x_peadiagonaalil(bingo_tabel))
print(x_korvaldiagonaalil(bingo_tabel))
print(voitis_diagonaalidemangu(bingo_tabel))
print(voitis_taismangu(bingo_tabel))
def tulemus(sudoku):
    if kastid_korras(sudoku) and read_korras(sudoku) and veerud_korras(sudoku):
        return 'OK'
    else:
        return 'VIGA'

def kastid_korras(sudoku):
    for rea_nurk in range(0, 9, 3):
        for veeru_nurk in range(0, 9, 3):
            kast = []
            for i in range(3):
                for j in range(3):
                    kast.append(int(sudoku[rea_nurk + i][veeru_nurk + j]))
            if sorted(kast) != list(range(1, 10)):
                return False
    return True

def read_korras(sudoku):
    for i in range(9):
        if sorted(sudoku[i]) != list(range(1, 10)):
            return False
    return True

def veerud_korras(sudoku):
    for rea in range(0, 9, 1):
        for veeru in range(0, 9, 1):
            veerg = []
            for i in range(1):
                for j in range(9):
                    veerg.append(int(sudoku[rea + j][veeru + i]))
            if sorted(veerg) != list(range(1, 10)):
                return False
            else:
                return True
    
fail = input("Sisestage failinimi: ")
f = open(fail, encoding = "UTF-8")
sudoku = []
for rida in f:
    a = rida.split()
    a = list(map(int, a))
    sudoku.append(a)
f.close()
print(tulemus(sudoku))

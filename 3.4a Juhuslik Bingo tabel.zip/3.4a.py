import random
def juhuslik_bingo():
    a = random.sample(range(1, 16), 5)
    b = random.sample(range(16, 31), 5)
    c = random.sample(range(31, 46), 5)
    d = random.sample(range(46, 61), 5)
    e = random.sample(range(61, 76), 5)
    tulemus = [a, b, c, d, e]
    sorteerimine = list(map(list, zip(*tulemus)))
    return sorteerimine
print(juhuslik_bingo())